


const Spacer = (props) => {
    let spacerStyles = {
        height: props.height + 'rem',
        width: props.width + 'rem'
    };
    return (<div style={spacerStyles}> </div>)
};

export default Spacer;
