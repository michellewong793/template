# personalsite
Personal Site with Netlify
I use this to host my resume, mostly, for now. It uses Next.js and was fun to set up and deploy. 

To run on your own machine, first run `yarn` at the root to download dependencies.
Then, run `yarn dev` at the root to start running the project at localhost:3000. 

Feel free to fork and take it and make it your own and use this as a template! 

Thank you for checking my website out :) 

[micheburrito.com](https://www.micheburrito.com)
